package com.example.piiicks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
