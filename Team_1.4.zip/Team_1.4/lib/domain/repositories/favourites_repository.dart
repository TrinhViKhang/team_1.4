
abstract class FavoriteProductRepository {

}
