import 'cart_item.dart';

class Cart {
  final List<CartItem> items;

  Cart({required this.items});
}
