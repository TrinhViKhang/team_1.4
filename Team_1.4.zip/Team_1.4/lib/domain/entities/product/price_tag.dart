class PriceTag {
  final String id;
  final String name;
  final num price;

  PriceTag({
    required this.id,
    required this.name,
    required this.price,
  });
}
