import 'category.dart';

class CategoryResponse {
  final List<Category> categories;

  CategoryResponse({required this.categories});
}
