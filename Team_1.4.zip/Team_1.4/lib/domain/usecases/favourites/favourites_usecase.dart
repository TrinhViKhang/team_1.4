/*
import 'package:piiicks/data/models/favourite_produt/favourit_product_model.dart';

import '../../repositories/favourites_repository.dart';

class ManageFavoritesUseCase {
  final FavoriteProductRepository favoriteProductRepository;

  ManageFavoritesUseCase({required this.favoriteProductRepository});

  Future<void> addToFavorites(FavouriteProductModel favouriteProductModel) {
    return favoriteProductRepository.addToFavorites(favouriteProductModel);
  }

  Future<void> removeFromFavorites(String favouriteProductId) {
    return favoriteProductRepository.removeFromFavorites(favouriteProductId);
  }

  Future<List<FavouriteProductModel>> getFavoriteProducts() {
    return favoriteProductRepository.getFavoriteProducts();
  }
}
*/
