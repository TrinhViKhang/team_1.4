enum SortOrder {newest, highToLow, lowToHigh, aToZ, zToA }

enum PaymentMethod {knet, visa}

enum NavigationTab { homeTab, categoriesTab, productsTap, cartTab, profileTab }
