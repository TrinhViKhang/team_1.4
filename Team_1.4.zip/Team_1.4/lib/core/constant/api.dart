const String baseUrl = 'https://rich-jade-mackerel-kit.cyclic.app';
const String defaultApiKey = '';
const String defaultSources = '';